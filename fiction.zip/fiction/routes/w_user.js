const express = require('express')
const pool = require('./pool')
var router = express.Router()


router.get('/history_list',function(req,res){
    var json = req.query
    console.log(json)
    pool.conn({
        arr:[json.uid],
        sql:'select * from history_list where bookuid=?',
        success:function(data){
            res.send('ok')
        },
        error:function(err){
            res.send(err)
        }
    })
})

router.post('/intos',function(req,res){
    var json = req.body
    pool.conn({
        arr:[json.bookurl,json.bookname,json.bookauthor,json.bookcata,json.bookcontent,json.loginuid],
        sql:'insert into intos(bookurl,bookname,bookauthor,bookcata,bookcontent,loginuid) values(?,?,?,?,?,?)',
        success:function(data){
            res.send('ok')
        },
        error:function(err){
            res.send(err)
        }
    })
})

router.post('/my_list',function(req,res){
    var json = req.body
    pool.conn({
        arr:[json.bookname,json.bookcontent,json.bookuid],
        sql:'insert into my_list(name,text,bookuid) values(?,?,?)',
        success:function(data){
            res.send('ok')
        },
        error:function(err){
            res.send(err)
        }
    })
})


// router.get('/delete',function(req,res){
//     var json = req.query
//     pool.conn({
//         arr:[json.uid],
//         sql:'delect from into where uid =?',
//         success:function(data){
//             res.send('ok')
//         },
//         error:function(err){
//             res.send(err)
//         }
//     })
// })

router.post('/update',function(req,res){
    var json = req.query
    pool.conn({
        arr:[json.bookname,json.bookcontent,json.bookurl,json.uid],
        sql:'update into set bookname=?,bookcontent=?,bookurl=? where uid=?',
        success:function(data){
            res.send('ok')
        },
        error:function(err){
            res.send(err)
        }
    })
})



router.get('/my',function(req,res){
    var json = req.query
    console.log(json)
    pool.conn({
        arr:[json.loginuid],
        sql:'select uid,bookname,bookurl,bookauthor,bookcata,bookcontent from intos where loginuid=?',
        success:function(data){
            res.send(data)
        },
        error:function(err){
            res.send(err)
        }
    })
})

router.get('/del',(req,res)=>{
    var json = req.query
    pool.conn({
        arr:[json.loginuid],
        sql:'delete from intos where loginuid=?',
        success:function(data){
            res.send(data)
        },
        error:function(err){
            res.send(err)
        }
    })
})

module.exports = router