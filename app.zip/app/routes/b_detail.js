const express = require('express');
var pool = reqiure('./routes/b_pool');
var router = express.Router();

router.get('/b_detail',function(req,res){
	var json = req.query;
	var type = 
})



