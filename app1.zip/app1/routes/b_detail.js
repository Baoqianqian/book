const express = require('express');
var pool = require('./b_pool')
var router = express.Router();

//评论
router.get('/b_detail',function(req,res){
	var json = req.query;
	console.log(json)
	pool.conn({
		arr:[json.img,json.fiction_name,json.fiction_author,json.content],
		sql:'insert into fiction_detail(img,fiction_name,fiction_author,content)values(?,?,?,?)',
		success(data){
			res.send('ok')
		},
		error(err){
			res.send(err)
		}
	})
	//res.send('ok')
	//var type = 
})

//搜索
router.get('/search',(req,res)=>{
	var json = req.query;
	console.log(json);
	pool.conn({
		arr:[json.names],
		sql:'select * from into where bookname=?',
		success(data){
			res.send(data)
		},
		error(err){
			res.send(err)
		}
	})
})
module.exports = router


