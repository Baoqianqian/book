var express = require('express');
var router = express.Router();
var pool = require('./pool');


/* GET users listing. */
router.get('/', function(req, res, next) {
	res.send('respond with a resource');
});

router.post('/in',function(req,res){
	var json = req.body;
	console.log(json);
	pool.conn({
		arr:[json.user],
		sql:'select user from login where user=?',
		success(data){
			if(data.length){
				res.send('账号已存在');
			}else{
				pool.conn({
					arr:[json.user, json.pass, json.name, json.imgurl],
					sql:'insert into login(user,pass,name,imgurl) values(?,?,?,?)',
					success(data){
						res.send('注册成功了');
					},
					error(err){
						res.send(err)
					}
				})
			}
		},
		error(err){
			res.send(err);
		}
	})
})
router.post('/up',(req,res)=>{
	var json = req.body;
	pool.conn({
		arr:[json.user, json.pass],
		sql:'select * from login where user=? and pass=?',
		success(data){
			if(data.length){
				data[0].pass = '';
				res.send(data[0]);
			}else{
				res.send('账号密码不匹配');
			}
		},
		error(err){
			res.send(err);
		}
	})
})





module.exports = router;
